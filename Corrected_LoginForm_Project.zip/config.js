

let rootpath="https://mysite.itvarsity.org/api/contactBook/";
let apikey = CheckApikey();

function CheckApikey() {
  if(!localStorage.getItem("apikey")) {
    window.open("enter-api-key.html","_self");
  }
   return localStorage.getItem("apikey");
}